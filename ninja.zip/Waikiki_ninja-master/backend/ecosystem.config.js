module.exports = {
  apps: [
    {
      name: 'ninja',
      script: './app.js',
    },
  ],
};
