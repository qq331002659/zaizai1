<template>
  <transition name="fade">
    <div
      class="
        flex
        justify-center
        items-center
        w-screen
        h-screen
        bg-opacity-30 bg-black
        z-50
        absolute
        backdrop-filter backdrop-blur-sm
      "
    >
      <zi-spinner big />
    </div>
  </transition>
</template>

<script>
export default {}
</script>

<style></style>
